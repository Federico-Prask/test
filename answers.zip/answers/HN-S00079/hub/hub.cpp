#include<bits/stdc++.h>
using namespace std;
void work()
{
	srand(time(0));
	cout<<rand()<<'\n';
}
int main()
{
	freopen("hub.in","r",stdin);
	freopen("hub.out","w",stdout);
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	cin>>c>>t;
	while(t--)work();
	return 0;
}
/*

0 2
5 2
1 2
2 3
3 4
4 5
10 3
1 2
1 3
2 4
2 5
3 6
3 7
3 8
7 9
9 10

*/


//��Ը��ϣ������һ��qwq  
