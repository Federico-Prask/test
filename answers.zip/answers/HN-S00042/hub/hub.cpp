#include<bits/stdc++.h> 
using namespace std;

int main(){
	ios::sync_with_stdio(0);
	cin.tie(0);cout.tie(0);
	freopen("hub.in","r",stdin);
	freopen("hub.out","w",stdout);
	cout<<"1\n2";
	return 0;
}
/*
��עHamster_Emperorлл�� 
*/
